package com.example.dreamproject.checkingtheedittextfrommysql;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.dreamproject.R;

public class MainActivity extends AppCompatActivity {
    private static final String SERVER_URL = "http://192.168.43.78:8080/checkedittext/CheckingEdit";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_checking_edit_text_mysql);

        final EditText editTextValue = findViewById(R.id.editText2_check);
        EditText editTextPassword = findViewById(R.id.editText2_check_password);
        Button checkButton = findViewById(R.id.nextButton_check);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the value from the EditText
                String valueToCheck = editTextValue.getText().toString().trim();
                String valueToPassword = editTextPassword.getText().toString().trim();

                // Check if the value is empty
                if (valueToCheck.isEmpty() || valueToPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a value", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Make a GET request to the server
                //String url = SERVER_URL + "?value=" + valueToCheck + "?value=" + valueToPassword;

                String url = SERVER_URL + "?value=" + valueToCheck + "&password=" + valueToPassword;


                StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.equals("exists")) {
                            // Value exists in the database, switch to the next activity
                            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                            startActivity(intent);
                        } else {
                            // Value does not exist in the database, display a toast
                            Toast.makeText(MainActivity.this, "Value does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error (e.g., network error)
                        Toast.makeText(MainActivity.this, "Error occurred", Toast.LENGTH_SHORT).show();
                    }
                });

                // Add the request to the Volley request queue
                Volley.newRequestQueue(MainActivity.this).add(stringRequest);
            }
        });
    }
}
