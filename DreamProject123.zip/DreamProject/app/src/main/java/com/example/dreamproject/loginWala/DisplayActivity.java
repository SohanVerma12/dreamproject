package com.example.dreamproject.loginWala;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dreamproject.R;

public class DisplayActivity extends AppCompatActivity {

    private TextView displayTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        displayTextView = findViewById(R.id.displayTextView);

        // Retrieve data from the intent
        Intent intent = getIntent();
        String text1 = intent.getStringExtra("text1");
        String text2 = intent.getStringExtra("text2");

        // Display the text in the TextView
        displayTextView.setText("Text 1: " + text1 + "\nText 2: " + text2);
    }
}

