package com.example.dreamproject.examplsearch;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ListView;

import com.example.dreamproject.R;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private AutoCompleteTextView autoCompleteTextView;
    private Button addButton;
    private ListView listView;
    private ArrayAdapter<String> autoCompleteAdapter;
    private ArrayAdapter<String> listAdapter;
    private ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_examplsearch);

        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        addButton = findViewById(R.id.addButton);
        listView = findViewById(R.id.listView);

        // Initialize the AutoCompleteTextView with hardcoded items
        autoCompleteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, getResources().getStringArray(R.array.items));
        autoCompleteTextView.setAdapter(autoCompleteAdapter);

        // Initialize the ListView and its adapter
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, selectedItems);
        listView.setAdapter(listAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedItem = autoCompleteTextView.getText().toString();
                if (!selectedItem.isEmpty()) {
                    selectedItems.add(selectedItem);
                    listAdapter.notifyDataSetChanged();
                    autoCompleteTextView.setText("");
                }
            }
        });
    }
}
