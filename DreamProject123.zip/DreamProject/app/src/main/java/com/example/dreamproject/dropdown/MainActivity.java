package com.example.dreamproject.dropdown;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.example.dreamproject.R;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private TextView dropdownTextView12;
    private TextView dropdownTextView123;
    private Button showButton;
    private ListView listView;
    private ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dropdown);

        dropdownTextView12 = findViewById(R.id.dropdownTextView12);
        dropdownTextView123 = findViewById(R.id.dropdownTextView123);
        showButton = findViewById(R.id.showButton);
        listView = findViewById(R.id.listView);
    }

    public void showPopupMenu12(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view, Gravity.END);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu_examples, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                String selectedItem = item.getTitle().toString();
                dropdownTextView12.setText(selectedItem);
                return true;
            }
        });

        popupMenu.show();
    }

    public void showPopupMenu123(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view, Gravity.END);
        popupMenu.getMenuInflater().inflate(R.menu.popup_menu_examples, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                String selectedItem = item.getTitle().toString();
                dropdownTextView123.setText(selectedItem);
                return true;
            }
        });

        popupMenu.show();
    }

    public void showSelectionInListView(View view) {
        selectedItems.clear();
        selectedItems.add(dropdownTextView12.getText().toString());
        selectedItems.add(dropdownTextView123.getText().toString());

        ArrayAdapter<String> selectedAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, selectedItems);
        listView.setAdapter(selectedAdapter);
    }
}
