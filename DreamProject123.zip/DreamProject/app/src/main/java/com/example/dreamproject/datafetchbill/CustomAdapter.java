package com.example.dreamproject.datafetchbill;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.dreamproject.R;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<DataItem> {
    private Context context;
    private ArrayList<DataItem> dataItemList;

    public CustomAdapter(Context context, ArrayList<DataItem> dataItemList) {
        super(context, 0, dataItemList);
        this.context = context;
        this.dataItemList = dataItemList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(context).inflate(
                    R.layout.list_item_bill, parent, false);
        }

        DataItem currentItem = dataItemList.get(position);

        TextView idTextView = listItemView.findViewById(R.id.idTextView);
        TextView option1TextView = listItemView.findViewById(R.id.option1TextView);
        TextView option2TextView = listItemView.findViewById(R.id.option2TextView);

        idTextView.setText(String.valueOf(currentItem.getId()));
        option1TextView.setText(currentItem.getOption1());
        option2TextView.setText(currentItem.getOption2());

        return listItemView;
    }
}

