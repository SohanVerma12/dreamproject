package com.example.dreamproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private TextView dropdownTextView, dropdownTextView2, dropdownTextView3, dropdownTextView4;
    //    Button btn_click;
    private String selectedOption = "Select an option"; // Default value

    private String selectedOption2 = "Select an option"; // Default value

    private String selectedOption3 = "Select an option"; // Default value

    private String selectedOption4 = "Select an option"; // Default value


    //private AutoCompleteTextView autoCompleteTextView;
    private EditText quantityEditText;
    private Button addButton;
    private ImageView dropdownIcon; // Added ImageView
    private ListView listView;
    //private ArrayAdapter<String> autoCompleteAdapter;
    private ArrayAdapter<String> listAdapter;
    private ArrayList<String> selectedItems = new ArrayList<>();


    //autocompletedtextview
//    private AutoCompleteTextView autoCompleteTextView;
    private ArrayAdapter<String> autoCompleteAdapter;
    private List<String> allItems = new ArrayList<>();

    private AutoCompleteTextView autoCompleteTextView;
    private TextView itemCodeTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dropdownTextView = findViewById(R.id.dropdownTextView1);
        dropdownTextView2 = findViewById(R.id.dropdownTextView2);
        dropdownTextView3 = findViewById(R.id.dropdownTextView3);
        dropdownTextView4 = findViewById(R.id.remarkdropdownTextView3);

//        btn_click = findViewById(R.id.btn_click);



        // Retrieve the text data from the intent
        Intent intent = getIntent();
        String textReceived = intent.getStringExtra("text1");

// Save the text data in SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("text1", textReceived);
        editor.apply();


        quantityEditText = findViewById(R.id.quantityEditText);
        addButton = findViewById(R.id.addButton);
        dropdownIcon = findViewById(R.id.dropdownIcon); // Initialize ImageView
        listView = findViewById(R.id.listView);

     //   autoCompleteTextView = findViewById(R.id.autoCompleteTextView);

        /*autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        autoCompleteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line);
        autoCompleteTextView.setAdapter(autoCompleteAdapter);


        // Add a TextWatcher to filter suggestions as the user types
        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Filter the suggestions based on the text entered by the user
                List<String> filteredItems = new ArrayList<>();
                for (String item : allItems) {
                    if (item.toLowerCase().contains(charSequence.toString().toLowerCase())) {
                        filteredItems.add(item);
                    }
                }
                autoCompleteAdapter.clear();
                autoCompleteAdapter.addAll(filteredItems);
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

*/

        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        itemCodeTextView = findViewById(R.id.itemCodeTextView_main); // Initialize TextView


        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                itemCodeTextView.setText(""); // Clear previous item code
                fetchItemCode(selectedItem); // Fetch and display item code


            }
        });

        // Listen to text changes and fetch suggestions
        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString();
                fetchSuggestions(query, adapter);


            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });


    // Initialize the AutoCompleteTextView with hardcoded items
//        autoCompleteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line,
//                getResources().getStringArray(R.array.items));
//        autoCompleteTextView.setAdapter(autoCompleteAdapter);

        // Initialize the ListView and its adapter
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, selectedItems);
        listView.setAdapter(listAdapter);

        // Handle the click on the dropdown icon
        dropdownIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                autoCompleteTextView.showDropDown();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedItem = autoCompleteTextView.getText().toString();
                String quantity = quantityEditText.getText().toString();
                String remark = dropdownTextView4.getText().toString();

                if (!selectedItem.isEmpty() && !quantity.isEmpty() && !remark.isEmpty()) {
                    String itemWithQuantity = selectedItem + " (Qty: " + quantity + ")" + remark;
                    selectedItems.add(itemWithQuantity);
                    listAdapter.notifyDataSetChanged();
                    autoCompleteTextView.setText("");
                    quantityEditText.setText("");
                    dropdownTextView4.setText("Remark");
                }
            }
        });

    }
//    end

    public void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenu().add("101");
        popupMenu.getMenu().add("102");
        popupMenu.getMenu().add("103");
        popupMenu.getMenu().add("104");
        popupMenu.getMenu().add("105");

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // Handle item click
                selectedOption = item.getTitle().toString(); // Store selected option
                dropdownTextView.setText(selectedOption);
                return true;
            }
        });

        popupMenu.show();
    }

    public void showPopupMenu2(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenu().add("1");
        popupMenu.getMenu().add("2");
        popupMenu.getMenu().add("3");
        popupMenu.getMenu().add("4");
        popupMenu.getMenu().add("5");

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // Handle item click
                selectedOption2 = item.getTitle().toString(); // Store selected option
                dropdownTextView2.setText(selectedOption2);
                return true;
            }
        });

        popupMenu.show();
    }


    public void showPopupMenu3(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenu().add("Avinash");
        popupMenu.getMenu().add("Sohan");
        popupMenu.getMenu().add("Raju");
        popupMenu.getMenu().add("Ashish");
        popupMenu.getMenu().add("Omkar");

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // Handle item click
                selectedOption3 = item.getTitle().toString(); // Store selected option
                dropdownTextView3.setText(selectedOption3);
                return true;
            }
        });

        popupMenu.show();
    }


    public void showPopupMenu4(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenu().add("Soft");
        popupMenu.getMenu().add("Hold");
        popupMenu.getMenu().add("Spicy");
        popupMenu.getMenu().add("Normal");
        popupMenu.getMenu().add("Fast");

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                // Handle item click
                selectedOption4 = item.getTitle().toString(); // Store selected option
                dropdownTextView4.setText(selectedOption4);
                return true;
            }
        });

        popupMenu.show();
    }


   /* public void onClickButton(View view) {
        // Start the next activity and pass the selected option
        Intent intent = new Intent(this, NextActivity.class);
        intent.putExtra("selectedOption", selectedOption);
        intent.putExtra("selectedOption2", selectedOption2);
        intent.putExtra("selectedOption3", selectedOption3);
        startActivity(intent);
    }
    */

    public void onClickNextButton(View view) {
        // Start the next activity and pass the selected options and the list of items
        Intent intent = new Intent(this, NextActivity.class);
        intent.putExtra("selectedOption1", selectedOption);
        intent.putExtra("selectedOption2", selectedOption2);
        intent.putExtra("selectedOption3", selectedOption3);
        intent.putExtra("selectedOption4", selectedOption4);
        intent.putStringArrayListExtra("selectedItems", selectedItems);
        startActivity(intent);
    }

    private void fetchSuggestions(final String query, final ArrayAdapter<String> adapter) {
        new AsyncTask<Void, Void, JSONArray>() {
            @Override
            protected JSONArray doInBackground(Void... params) {
                try {
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder()
                            .url("http://192.168.43.78:8080/autocompletetextview/autocompletetextview?query=" + query)
                            .build();
                    Response response = client.newCall(request).execute();
                    String jsonData = response.body().string();
                    return new JSONArray(jsonData);


                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(JSONArray itemNames) {
                if (itemNames != null) {

                    Log.d("Suggestions", "Received suggestions: " + itemNames.toString());
                    adapter.clear();
                    for (int i = 0; i < itemNames.length(); i++) {
                        try {
                            JSONObject item = itemNames.getJSONObject(i);
                            String itemName = item.getString("itemName");

                            System.out.println(itemName);
                            adapter.add(itemName);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        }.execute();
    }



    private void fetchItemCode(final String itemName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://192.168.43.78:8080/autocompletetextview/getitemcode?itemName=" + itemName)
                        .build();
                try {
                    Response response = client.newCall(request).execute();
                    if (response.isSuccessful()) {
                        final String itemCode = response.body().string();
                        Log.d("ItemCode", "Received item code: " + itemCode); // Debugging
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                itemCodeTextView.setText("Item Code: " + itemCode);
                            }
                        });
                    } else {
                        Log.d("ItemCode", "Item Code not found"); // Debugging
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                itemCodeTextView.setText("Item Code not found");
                            }
                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("ItemCode", "Error fetching item code: " + e.getMessage()); // Debugging
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            itemCodeTextView.setText("Error fetching item code");
                        }
                    });
                }
            }
        }).start();
    }

}
