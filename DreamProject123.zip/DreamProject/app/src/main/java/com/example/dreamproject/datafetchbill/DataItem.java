package com.example.dreamproject.datafetchbill;

public class DataItem {
    private int id;
    private String option1;
    private String option2;

    public DataItem(int id, String option1, String option2) {
        this.id = id;
        this.option1 = option1;
        this.option2 = option2;
    }

    public int getId() {
        return id;
    }

    public String getOption1() {
        return option1;
    }

    public String getOption2() {
        return option2;
    }
}

