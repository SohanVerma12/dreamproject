package com.example.dreamproject.bill;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dreamproject.R;

import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private Button openPopupButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bill_pop);

        openPopupButton = findViewById(R.id.openPopupButton);
        openPopupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupDialog();
            }
        });
    }

    private void showPopupDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Table Items and Prices");

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://your_server_url/your_servlet_url")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Handle failure (e.g., show an error message)
                        showDialog("Error", "Failed to fetch data from the server.");
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String responseData = response.body().string();
                    try {
                        final JSONArray jsonArray = new JSONArray(responseData);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // Display data from the jsonArray in the dialog
                                String[] items = new String[jsonArray.length()];
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    try {
                                        items[i] = jsonArray.getString(i);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    showDialog("Table Items", String.join("\n", items));
                                }
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Handle non-successful response (e.g., show an error message)
                            showDialog("Error", "Failed to fetch data from the server.");
                        }
                    });
                }
            }
        });
    }

    private void showDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }
}

