package com.example.dreamproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class NextActivity extends AppCompatActivity {

    Button button_upload;
    TextView option1TextView;
    TextView option2TextView;
    TextView option3TextView;
    TextView option4TextView;
    TextView selectedItemsTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        button_upload = findViewById(R.id.button_upload);
        option1TextView = findViewById(R.id.option1TextView);
        option2TextView = findViewById(R.id.option2TextView);
        option3TextView = findViewById(R.id.option3TextView);
        option4TextView = findViewById(R.id.option4TextView);
        selectedItemsTextView = findViewById(R.id.selectedItemsTextView);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String textReceived = sharedPreferences.getString("text1", "Default Text");

// Now, you can use the receivedText as needed in the Third Activity
        TextView textView = findViewById(R.id.displayTextView12); // Replace with your TextView
        textView.setText(textReceived);


        // Retrieve data from the intent
        Intent intent = getIntent();
        String selectedOption1 = intent.getStringExtra("selectedOption1");
        String selectedOption2 = intent.getStringExtra("selectedOption2");
        String selectedOption3 = intent.getStringExtra("selectedOption3");
        String selectedOption4 = intent.getStringExtra("selectedOption4");
        ArrayList<String> selectedItems = intent.getStringArrayListExtra("selectedItems");

        // Display the retrieved data in TextViews
        option1TextView.setText("Table No            : " + selectedOption1);
        option2TextView.setText("Covers                : " + selectedOption2);
        option3TextView.setText("Stevar                 : " + selectedOption3);
        option4TextView.setText("Remark              : " + selectedOption4);

        // Convert the selectedItems ArrayList to a formatted string for display
        StringBuilder itemsStringBuilder = new StringBuilder();
        for (String item : selectedItems) {
            itemsStringBuilder.append(item).append("\n");
        }
        selectedItemsTextView.setText("Selected Items:\n" + itemsStringBuilder.toString());

        // Set up a click listener for the upload button
        button_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text from TextViews
                String option1Text = option1TextView.getText().toString();
                String option2Text = option2TextView.getText().toString();
                String option3Text = option3TextView.getText().toString();
                String selectedItemsText = selectedItemsTextView.getText().toString();

                String option4Text = option4TextView.getText().toString();

                // Execute AsyncTask to send data to the servlet
                SendDataToServletTask sendDataToServletTask = new SendDataToServletTask();
                sendDataToServletTask.execute(option1Text, option2Text, option3Text, selectedItemsText, option4Text);
            }
        });
    }

    private class SendDataToServletTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String option1 = params[0];
            String option2 = params[1];
            String option3 = params[2];
            String selectedItems = params[3];
            String option4 = params[4];

            try {
                // Replace the URL with the actual URL of your Java Servlet
                URL url = new URL("http://192.168.43.78:8080/fuckingthings/InsertDataServlet");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);

                // Create a query string with your data
                String query = "option1=" + option1 + "&option2=" + option2 + "&option3=" + option3 + "&selectedItems=" + selectedItems + "&option4=" + option4;

                OutputStream os = conn.getOutputStream();
                os.write(query.getBytes("UTF-8"));
                os.flush();
                os.close();

                // Get the response from the server
                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read and return the response from the server
                    // You can parse the response here if needed
                    return "Data uploaded successfully.";
                } else {
                    return "HTTP Error: " + responseCode;
                }
            } catch (Exception e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
        }
    }
}
