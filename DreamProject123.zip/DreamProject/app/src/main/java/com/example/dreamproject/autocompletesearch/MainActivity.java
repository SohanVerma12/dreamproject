package com.example.dreamproject.autocompletesearch;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dreamproject.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView autoCompleteTextView;
    private TextView itemCodeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_autocompletesearch_servlet);

        autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
        itemCodeTextView = findViewById(R.id.itemCodeTextView); // Initialize TextView

        // Set up AutoCompleteTextView adapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                itemCodeTextView.setText(""); // Clear previous item code
                fetchItemCode(selectedItem); // Fetch and display item code


            }
        });

        // Listen to text changes and fetch suggestions
        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString();
                fetchSuggestions(query, adapter);


            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void fetchSuggestions(final String query, final ArrayAdapter<String> adapter) {
        new AsyncTask<Void, Void, JSONArray>() {
            @Override
            protected JSONArray doInBackground(Void... params) {
                try {
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder()
                            .url("http://192.168.43.78:8080/autocompletetextview/autocompletetextview?query=" + query)
                            .build();
                    Response response = client.newCall(request).execute();
                    String jsonData = response.body().string();
                    return new JSONArray(jsonData);


                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(JSONArray itemNames) {
                if (itemNames != null) {

                    Log.d("Suggestions", "Received suggestions: " + itemNames.toString());
                    adapter.clear();
                    for (int i = 0; i < itemNames.length(); i++) {
                        try {
                            JSONObject item = itemNames.getJSONObject(i);
                            String itemName = item.getString("itemName");

                            System.out.println(itemName);
                            adapter.add(itemName);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        }.execute();
    }

    private void fetchItemCode(final String itemName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://192.168.43.78:8080/autocompletetextview/getitemcode?itemName=" + itemName)
                        .build();
                try {
                    Response response = client.newCall(request).execute();
                    if (response.isSuccessful()) {
                        final String itemCode = response.body().string();
                        Log.d("ItemCode", "Received item code: " + itemCode); // Debugging
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                itemCodeTextView.setText("Item Code: " + itemCode);
                            }
                        });
                    } else {
                        Log.d("ItemCode", "Item Code not found"); // Debugging
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                itemCodeTextView.setText("Item Code not found");
                            }
                        });
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("ItemCode", "Error fetching item code: " + e.getMessage()); // Debugging
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            itemCodeTextView.setText("Error fetching item code");
                        }
                    });
                }
            }
        }).start();
    }

}