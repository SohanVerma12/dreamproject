package com.example.dreamproject.datafetchbill;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.dreamproject.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String SERVER_URL = "http://localhost:8080/BillShowing/BillServlet";
    private ListView listView;
    private CustomAdapter customAdapter;
    private ArrayList<DataItem> dataItemList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bill);

        listView = findViewById(R.id.listView);
        customAdapter = new CustomAdapter(this, dataItemList);
        listView.setAdapter(customAdapter);

        fetchDataFromServlet();
    }

    private void fetchDataFromServlet() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, SERVER_URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        parseJSONData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void parseJSONData(JSONArray jsonArray) {
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                int id = jsonObject.getInt("id");
                String option1 = jsonObject.getString("option1");
                String option2 = jsonObject.getString("option2");
                // ... (repeat for other columns)

                // Create a DataItem object and add it to the list
                DataItem dataItem = new DataItem(id, option1, option2);
                dataItemList.add(dataItem);
            }

            // Notify the adapter that the data has changed
            customAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(MainActivity.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
        }
    }
}
