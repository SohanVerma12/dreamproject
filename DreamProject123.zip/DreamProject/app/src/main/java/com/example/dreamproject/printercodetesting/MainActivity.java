package com.example.dreamproject.printercodetesting;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dreamproject.R;

import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private TextView textView1;
    private TextView textView2;
    private Button printButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_printer);

        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        printButton = findViewById(R.id.printButton);

        // Set up a click listener for the print button
        printButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text from TextViews
                String textToPrint = textView1.getText() + "\n" + textView2.getText();

                // Start the printing process
                printText(textToPrint);
            }
        });
    }

    private void printText(String textToPrint) {
        // Get the PrintManager
        PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);

        // Set a print job name
        String jobName = getString(R.string.app_name) + " Document";

        // Create a print job with a print adapter
        PrintJob printJob = printManager.print(jobName, new MyPrintDocumentAdapter(textToPrint), null);

        // Handle print job status here if needed
    }

    // Define a PrintDocumentAdapter for printing
    private class MyPrintDocumentAdapter extends PrintDocumentAdapter {
        private String textToPrint;

        MyPrintDocumentAdapter(String textToPrint) {
            this.textToPrint = textToPrint;
        }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
            // Handle the layout of the document
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback) {
            // Write the document content to the destination
            try {
                // Create a new output stream and write the text
                FileOutputStream outputStream = new FileOutputStream(destination.getFileDescriptor());
                outputStream.write(textToPrint.getBytes());

                // Notify the system that the write operation is complete
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});

                // Close the output stream
                outputStream.close();
            } catch (IOException e) {
                // Handle errors
                e.printStackTrace();
            }
        }
    }
}
