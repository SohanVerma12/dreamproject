package com.example.dreamproject.loginWala;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.dreamproject.NextActivity;
import com.example.dreamproject.R;

public class MainActivity extends AppCompatActivity {

    private EditText editText1;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_edittext);

        editText1 = findViewById(R.id.editText1);
        nextButton = findViewById(R.id.nextButton);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the text from EditText fields
                String text1 = editText1.getText().toString();

                // Create an intent to start DisplayActivity
                Intent intent = new Intent(MainActivity.this, com.example.dreamproject.MainActivity.class);

                intent.putExtra("text1", text1);
                // Pass data to the next activity
//                intent.putExtra("text1", text1);

                // Start the next activity
                startActivity(intent);



            }
        });
    }
}

